from pyrogram import Client,filters
import redis



api_id = 12664498
api_hash = "c1267cbd742729575b284495dfd9f068"
token = token = input("Enter Token : ")
sudo_id = 5328713035
plugins = dict(root="plugins")
                 
def Owner(msg):
  if (msg.from_user.id == sudo_id) :
    ok = True
  else :
    ok = False
  return ok
  
app = Client("bot_y", bot_token=token, api_id = api_id, api_hash = api_hash,plugins=plugins)