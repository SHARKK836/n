from config import *

print("""
Bot started 

By : @L_H_V 
""")
app.run()